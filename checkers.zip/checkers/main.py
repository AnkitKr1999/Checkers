import pygame
from fixed import *
from board import *
from part import *
from game import *
from minimax_algo import *
# doing the intials 
fps=60
window=pygame.display.set_mode((width,height))
pygame.display.set_caption('Checkers Game')

#setting up the mouse interactions

def get_pos_from_mouse(pos):
    x,y=pos
    row=y//sq_size
    col=x//sq_size
    return row,col

# generating the window setup event 
def main():
    clk = pygame.time.Clock()
    game = play(window)
    run=True
    # part = brd.get_part(0,1)
    # brd.update(part,5,4)
    while run:
        # print("1111111111111111111")
        clk.tick(fps)
        # if game.turn==white :
        #     # if game.get_brd()==None:
        #     #     print("gameboard")
        #     # elif game==None:
        #     #     print("game")
        #     board=game.get_brd()
        #     val,new_bd = minimax(board,3,white,game)
        #     game.ai_move(new_bd)

        for event in pygame.event.get():

            if event.type==pygame.MOUSEBUTTONDOWN:
                pos=pygame.mouse.get_pos()
                row,col=get_pos_from_mouse(pos)
                # part=brd.get_part(row,col)
                # brd.update(part,5,3)
                game.select(row,col)

            if event.type == pygame.QUIT:  #enabling the quit X button of the game window
                run=False

        # brd.draw_parts(window) # initializing the board setup
        # pygame.display.update() # updating the board setup
        game.update()


    pygame.quit()

main()