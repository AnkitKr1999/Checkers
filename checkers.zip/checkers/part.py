import pygame
from fixed import *

padding = 10
border=3

class parts:
    def __init__(self,row,col,colour):
        self.colour=colour
        self.king=False
        self.row=row
        self.col=col
        self.x=self.y=0
        if self.colour==white:
            self.dir=1
        else :
            self.dir=-1
        self.find_pos()
    
    def create_king(self): # creating a king
        self.king=True
    
    def draw_circle(self,window): # making circular board pieces with borders
        r=sq_size//2-padding
        pygame.draw.circle(window,grey,(self.x,self.y),r+border)
        pygame.draw.circle(window,self.colour,(self.x,self.y),r)
        if self.king:
            var1=self.x-apex.get_width()//2
            var2=self.y-apex.get_height()//2
            window.blit(apex,(var1,var2))
        
    def update(self,r,c):
        self.col=c
        self.row=r
        self.find_pos()

    def find_pos(self): # finding the position
        self.x=sq_size*self.col+sq_size//2
        self.y=sq_size*self.row+sq_size//2
    
    # def __repr__(self):
    #     return str(self.colour)