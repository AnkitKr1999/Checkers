import pygame
from fixed import *
from board import *

class play:
    def __init__(self,window):
        self.window=window
        self.s=None
        self.board=Bd()
        self.moves={}
        self.turn=red
    
    def update(self):
        self.board.draw_parts(self.window)
        self.make_valid_moves(self.moves)
        pygame.display.update()

    def fun(self):
        self.s=None
        self.board=Bd()
        self.moves={}
        self.turn=red
        
    def victor(self):
        return self.board.victor()

    def select(self,r,c):
        if self.s:
            val=self.move(r,c)
            if not val:
                self.s=None
                self.select(r,c)

        part=self.board.get_part(r,c)
        if part!=0 and part.colour==self.turn:
            self.s=part
            self.moves = self.board.get_moves(part)
            return True
        return False


    def move(self,r,c):
        part=self.board.get_part(r,c)
        if self.s and part==0 and (r,c) in self.moves:
            self.board.update(self.s,r,c)
            skipped=self.moves[(r,c)]
            if skipped:
                self.board.remove(skipped)
            self.update_turn()
        else:
            return False
        return True
    
    def update_turn(self):
        self.moves={}
        if self.turn==red:
            self.turn=white
        else:
            self.turn=red

    def renew(self):
        fun()
    
    def ai_move(self,brd):
        self.board=brd
        self.update_turn()

    def make_valid_moves(self,moves):
        for m in moves:
            r,c=m
            x=c*sq_size+sq_size//2
            y=r*sq_size+sq_size//2
            pygame.draw.circle(self.window,blue,(x,y),10)

        
    def get_brd(self):
        return self.board