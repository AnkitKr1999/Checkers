import pygame
from fixed import *
from copy import deepcopy # copying the refrence and object itself

# making evaluation at depth == 0
var=float('inf')
def get_moves(bd,colour,game):
    # print("111111111111111111")
    moves=[]
    tot=bd.get_all_parts(colour)
    for p in tot:
        valid = bd.get_moves(p)
        for m,s in valid.items():
            temp_bd = deepcopy(bd) # making a temporory copy of the original board to test the moves without rendring the original board
            temp_p=temp_bd.get_part(p.row,p.col)
            new_bd = control_move(temp_p,m,temp_bd,game,s) # test the move on the temporory board of a paritcular piece
            moves.append(new_bd)
    return moves

def minimax(pos,d,player,game):
    # print("11/11111111111111")
    if d==0 or pos.check_winner()!=None:
        # print("1111111111111")
        return pos.find_score(),pos

    if player:
        # print("1111111232311111111")
        maxval=-var
        best=None
        tot=get_moves(pos,white,game)
        for m in tot:
            # print("3")
            check=minimax(m,d-1,False,game)[0]
            maxval=max(maxval,check)
            if maxval == check:
                best=m
                # print("-1")
        return maxval,best
    else:
        # print("11111111111111")
        minval=var
        best=None
        tot=get_moves(pos,red,game)
        for m in tot:
            # print("3")
            check=minimax(m,d-1,True,game)[0]
            minval=min(minval,check)
            if minval==check:
                best=m
                # print("1")
            return minval,best


def control_move(part,move,bd,game,sk):
    x=move[0]
    y=move[1]
    bd.update(part,x,y) #moving the piece
    if sk:
        bd.remove(sk)
    return bd


    