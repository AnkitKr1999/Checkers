import pygame
# managing dimensions
width=820
height=820
rows=8
cols=8
sq_size=width//rows

# managing colours
blue=(0,0,255)
red=(255,0,0)
green=(0,80,0)
black=(0,0,0)
grey=(128,128,128)
white=(255,255,255)

# adjusting the crown for the king piece
img=pygame.image.load('crown.jpeg')
apex=pygame.transform.scale(img,(50,30))