import pygame
from fixed import *
from part import *
class Bd:
    def __init__(self):
        self.s_piece=None
        self.red_rem=12
        self.white_rem=12 # tracks the remaining pieces of each side
        self.bd=[]
        self.red_king=0
        self.white_king=0 # tracks the count of kings of each side
        self.generate_bd() 

    def make_cubes(self,window): # designing the board
        window.fill(white)
        for r in range(rows):
            for c in range(r%2,rows,2):
                x1=r*sq_size
                y1=c*sq_size
                x=sq_size
                pygame.draw.rect(window,green,(x1,y1,x,x))

    def draw_parts(self,window): # putting circles onto the squares
        self.make_cubes(window)
        for r in range(rows):
            for c in range(cols):
                part = self.bd[r][c]
                if part!=0:
                    part.draw_circle(window)

    def update(self,part,r,c):
        self.bd[part.row][part.col],self.bd[r][c]=self.bd[r][c],self.bd[part.row][part.col]
        part.update(r,c)
        if r==rows-1 or r==0:
            part.create_king()

    def generate_bd(self): # generating the board
        for r in range (rows):
            self.bd.append([])
            for c in range (cols):
                var1=c%2
                var2=(r+1)%2
                if var1==var2:
                    if r<3:
                        self.bd[r].append(parts(r,c,white))
                    elif r>4:
                        self.bd[r].append(parts(r,c,red))
                    else:
                        self.bd[r].append(0)
                else:
                    self.bd[r].append(0)
    
    def get_part(self,r,c):
        return self.bd[r][c]
    
    def get_moves(self,part):
        moves={}
        lt=part.col-1
        rt=part.col+1
        row=part.row
        if part.colour == red or part.king:
            # moves.update(self.travel_lt(row-1,max(row-3,-1),-1,part.colour,lt))
            
            moves.update(self.travel_lt(row-1,max(row-3,-1),-1,part.colour,lt))
            moves.update(self.travel_rt(row-1,max(row-3,-1),-1,part.colour,rt))
        
        if part.colour == white or part.king:
            moves.update(self.travel_lt(row+1,min(row+3,rows),1,part.colour,lt))
            moves.update(self.travel_rt(row+1,min(row+3,rows),1,part.colour,rt))
        
        return moves
    
    def travel_lt(self,start,end,steps,colour,lt,skipped=[]):
        moves={}
        last=[]
        for r in range(start,end,steps):
            if lt<0:
                break
            cur = self.bd[r][lt]
            if cur==0:
                if skipped and not last:
                    break
                elif skipped:
                    moves[(r,lt)] = last+skipped
                else :
                    moves[(r,lt)] = last
                if last:
                    if steps==-1:
                        row=max(r-3,0)
                    else:
                        row=min(r+3,rows)
                    moves.update(self.travel_lt(r+steps,row,steps,colour,lt-1,skipped=last))
                    moves.update(self.travel_rt(r+steps,row,steps,colour,lt+1,skipped=last))
                break
            elif cur.colour==colour:
                break
            else:
                last=[cur]

            lt-=1
        return moves
    def travel_rt(self,start,end,steps,colour,rt,skipped=[]):
        moves={}
        last=[]
        for r in range(start,end,steps):
            if rt>=cols:
                break
            cur = self.bd[r][rt]
            if cur==0:
                if skipped and not last:
                    break
                elif skipped:
                    moves[(r,rt)] = last+skipped
                else :
                    moves[(r,rt)] = last
                if last:
                    if steps==-1:
                        row=max(r-3,0)
                    else:
                        row=min(r+3,rows)
                    moves.update(self.travel_lt(r+steps,row,steps,colour,rt-1,skipped=last))
                    moves.update(self.travel_rt(r+steps,row,steps,colour,rt+1,skipped=last))
                break
            elif cur.colour==colour:
                break
            else:
                last=[cur]

            rt+=1
        return moves
    
    def remove(self,part):
        for piece in part:
            self.bd[piece.row][piece.col]=0
            if piece!=0:
                if piece.colour==red:
                    self.red_rem-=1
                else:
                    self.white_rem-=1
    
    def find_score(self):
        v1=self.white_rem-self.red_rem
        v2=self.white_king*0.5-self.red_king*0.5
        val=v1+v2
        return val
    
    def get_all_parts(self,colour):
        part=[]
        for r in self.bd:
            for p in r:
                if p != 0 and p.colour==colour:
                    part.append(p)
        return part  
    
    def check_winner(self):
        if self.red_rem <=0:
            return  white
        elif self.white_rem<=0:
            return red
        return None