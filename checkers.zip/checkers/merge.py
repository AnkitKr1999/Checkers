import pygame
from copy import deepcopy # copying the refrence and object itself
# managing dimensions
width=820
height=820
rows=8
cols=8
sq_size=width//rows

# managing colours
blue=(0,0,255)
red=(255,0,0)
black=(0,0,0)
grey=(128,128,128)
white=(255,255,255)

# adjusting the crown for the king piece
img=pygame.image.load('crown.jpeg')
apex=pygame.transform.scale(img,(50,30))

# setting the board dimensions
padding = 10
border=3
fps=60
window=pygame.display.set_mode((width,height))
pygame.display.set_caption('Checkers Game')

# setting up the mouse interactions

def get_pos_from_mouse(pos):
    x,y=pos
    row=y//sq_size
    col=x//sq_size
    return row,col

var=float('inf')
def get_moves(bd,colour,game):
    # print("111111111111111111")
    moves=[]
    tot=bd.get_all_parts(colour)
    for p in tot:
        valid = bd.get_moves(p)
        for m,s in valid.items():
            temp_bd = deepcopy(bd) # making a temporory copy of the original board to test the moves without rendring the original board
            temp_p=temp_bd.get_part(p.row,p.col)
            new_bd = control_move(temp_p,m,temp_bd,game,s) # test the move on the temporory board of a paritcular piece
            moves.append(new_bd)
    return moves

def minimax(pos,d,player,game):
    # print("11/11111111111111")
    if d==0 or pos.check_winner()!=None:
        # print("1111111111111")
        return pos.find_score(),pos

    if player:
        # print("1111111232311111111")
        maxval=-var
        best=None
        tot=get_moves(pos,white,game)
        for m in tot:
            # print("3")
            check=minimax(m,d-1,False,game)[0]
            maxval=max(maxval,check)
            if maxval == check:
                best=m
                # print("-1")
        return maxval,best
    else:
        # print("11111111111111")
        minval=var
        best=None
        tot=get_moves(pos,red,game)
        for m in tot:
            # print("3")
            check=minimax(m,d-1,True,game)[0]
            minval=min(minval,check)
            if minval==check:
                best=m
                # print("1")
            return minval,best


def control_move(part,move,bd,game,sk):
    x=move[0]
    y=move[1]
    bd.update(part,x,y) #moving the piece
    if sk:
        bd.remove(sk)
    return bd

class Bd:
    def __init__(self):
        self.s_piece=None
        self.red_rem=12
        self.white_rem=12 # tracks the remaining pieces of each side
        self.bd=[]
        self.red_king=0
        self.white_king=0 # tracks the count of kings of each side
        self.generate_bd() 

    def make_cubes(self,window): # designing the board
        window.fill(white)
        for r in range(rows):
            for c in range(r%2,rows,2):
                x1=r*sq_size
                y1=c*sq_size
                x=sq_size
                pygame.draw.rect(window,black,(x1,y1,x,x))

    def draw_parts(self,window): # putting circles onto the squares
        self.make_cubes(window)
        for r in range(rows):
            for c in range(cols):
                part = self.bd[r][c]
                if part!=0:
                    part.draw_circle(window)

    def update(self,part,r,c): #updating the cell
        self.bd[part.row][part.col],self.bd[r][c]=self.bd[r][c],self.bd[part.row][part.col]
        part.update(r,c)
        if r==rows-1 or r==0:
            part.create_king()

    def generate_bd(self): # generating the board
        for r in range (rows):
            self.bd.append([])
            for c in range (cols):
                var1=c%2
                var2=(r+1)%2
                if var1==var2:
                    if r<3:
                        self.bd[r].append(parts(r,c,white))
                    elif r>4:
                        self.bd[r].append(parts(r,c,red))
                    else:
                        self.bd[r].append(0)
                else:
                    self.bd[r].append(0)
    
    def get_part(self,r,c):
        return self.bd[r][c]
    
    def get_moves(self,part):
        moves={}
        lt=part.col-1
        rt=part.col+1
        row=part.row
        if part.colour == red or part.king:
            # moves.update(self.travel_lt(row-1,max(row-3,-1),-1,part.colour,lt))
            
            moves.update(self.travel_lt(row-1,max(row-3,-1),-1,part.colour,lt))
            moves.update(self.travel_rt(row-1,max(row-3,-1),-1,part.colour,rt))
        
        if part.colour == white or part.king:
            moves.update(self.travel_lt(row+1,min(row+3,rows),1,part.colour,lt))
            moves.update(self.travel_rt(row+1,min(row+3,rows),1,part.colour,rt))
        
        return moves
    
    def travel_lt(self,start,end,steps,colour,lt,skipped=[]):
        moves={}
        last=[]
        for r in range(start,end,steps):
            if lt<0:
                break
            cur = self.bd[r][lt]
            if cur==0:
                if skipped and not last:
                    break
                elif skipped:
                    moves[(r,lt)] = last+skipped
                else :
                    moves[(r,lt)] = last
                if last:
                    if steps==-1:
                        row=max(r-3,0)
                    else:
                        row=min(r+3,rows)
                    moves.update(self.travel_lt(r+steps,row,steps,colour,lt-1,skipped=last))
                    moves.update(self.travel_rt(r+steps,row,steps,colour,lt+1,skipped=last))
                break
            elif cur.colour==colour:
                break
            else:
                last=[cur]

            lt-=1
        return moves
    def travel_rt(self,start,end,steps,colour,rt,skipped=[]):
        moves={}
        last=[]
        for r in range(start,end,steps):
            if rt>=cols:
                break
            cur = self.bd[r][rt]
            if cur==0:
                if skipped and not last:
                    break
                elif skipped:
                    moves[(r,rt)] = last+skipped
                else :
                    moves[(r,rt)] = last
                if last:
                    if steps==-1:
                        row=max(r-3,0)
                    else:
                        row=min(r+3,rows)
                    moves.update(self.travel_lt(r+steps,row,steps,colour,rt-1,skipped=last))
                    moves.update(self.travel_rt(r+steps,row,steps,colour,rt+1,skipped=last))
                break
            elif cur.colour==colour:
                break
            else:
                last=[cur]

            rt+=1
        return moves
    
    def remove(self,part):
        for piece in part:
            self.bd[piece.row][piece.col]=0
            if piece!=0:
                if piece.colour==red:
                    self.red_rem-=1
                else:
                    self.white_rem-=1
    
    def find_score(self):
        v1=self.white_rem-self.red_rem
        v2=self.white_king*0.5-self.red_king*0.5
        val=v1+v2
        return val
    
    def get_all_parts(self,colour):
        part=[]
        for r in self.bd:
            for p in r:
                if p != 0 and p.colour==colour:
                    part.append(p)
        return part  
    
    def check_winner(self):
        if self.red_rem <=0:
            return  white
        elif self.white_rem<=0:
            return red
        return None

class parts:
    def __init__(self,row,col,colour):
        self.colour=colour
        self.king=False
        self.row=row
        self.col=col
        self.x=self.y=0
        if self.colour==white:
            self.dir=1
        else :
            self.dir=-1
        self.find_pos()
    
    def create_king(self): # creating a king
        self.king=True
    
    def draw_circle(self,window): # making circular board pieces with borders
        r=sq_size//2-padding
        pygame.draw.circle(window,grey,(self.x,self.y),r+border)
        pygame.draw.circle(window,self.colour,(self.x,self.y),r)
        if self.king:
            var1=self.x-apex.get_width()//2
            var2=self.y-apex.get_height()//2
            window.blit(apex,(var1,var2))
        
    def update(self,r,c):
        self.col=c
        self.row=r
        self.find_pos()

    def find_pos(self): # finding the position
        self.x=sq_size*self.col+sq_size//2
        self.y=sq_size*self.row+sq_size//2

class play:
    def __init__(self,window):
        self.window=window
        self.s=None
        self.board=Bd()
        self.moves={}
        self.turn=red
    
    def update(self):
        self.board.draw_parts(self.window)
        self.make_valid_moves(self.moves)
        pygame.display.update()

    def fun(self):
        self.s=None
        self.board=Bd()
        self.moves={}
        self.turn=red
        
    def victor(self):
        return self.board.victor()

    def select(self,r,c):
        if self.s:
            val=self.move(r,c)
            if not val:
                self.s=None
                self.select(r,c)

        part=self.board.get_part(r,c)
        if part!=0 and part.colour==self.turn:
            self.s=part
            self.moves = self.board.get_moves(part)
            return True
        return False


    def move(self,r,c):
        part=self.board.get_part(r,c)
        if self.s and part==0 and (r,c) in self.moves:
            self.board.update(self.s,r,c)
            skipped=self.moves[(r,c)]
            if skipped:
                self.board.remove(skipped)
            self.update_turn()
        else:
            return False
        return True
    
    def update_turn(self):
        self.moves={}
        if self.turn==red:
            self.turn=white
        else:
            self.turn=red

    def renew(self):
        fun()
    
    def ai_move(self,brd):
        self.board=brd
        self.update_turn()

    def make_valid_moves(self,moves):
        for m in moves:
            r,c=m
            x=c*sq_size+sq_size//2
            y=r*sq_size+sq_size//2
            pygame.draw.circle(self.window,blue,(x,y),10)

        
    def get_brd(self):
        return self.board
        
def main():
    clk = pygame.time.Clock()
    game = play(window)
    run=True
    # part = brd.get_part(0,1)
    # brd.update(part,5,4)
    while run:
        # print("1111111111111111111")
        clk.tick(fps)
        if game.turn==white :
            # if game.get_brd()==None:
            #     print("gameboard")
            # elif game==None:
            #     print("game")
            board=game.get_brd()
            val,new_bd = minimax(board,3,white,game)
            game.ai_move(new_bd)

        for event in pygame.event.get():

            if event.type==pygame.MOUSEBUTTONDOWN:
                pos=pygame.mouse.get_pos()
                row,col=get_pos_from_mouse(pos)
                # part=brd.get_part(row,col)
                # brd.update(part,5,3)
                game.select(row,col)

            if event.type == pygame.QUIT: # enabling the quit X button of the game window to quit on click
                run=False

        # brd.draw_parts(window) # initializing the board setup
        # pygame.display.update() # updating the board setup
        game.update()


    pygame.quit()

main()